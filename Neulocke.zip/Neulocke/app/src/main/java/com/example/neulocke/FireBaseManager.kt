package com.example.neulocke.firebase

import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ValueEventListener

class FirebaseManager {

    // =========================================================
    // FIREBASE AUTHENTICATION
    // =========================================================

    private val auth: FirebaseAuth =
        FirebaseAuth.getInstance()


    // =========================================================
    // FIREBASE REALTIME DATABASE
    // =========================================================

    private val database = FirebaseDatabase.getInstance(
        "https://neulocke-3deb5-default-rtdb.asia-southeast1.firebasedatabase.app"
    )

    private val db = database.reference


    // =========================================================
    // DOOR REFERENCE
    //
    // devices/door01
    // =========================================================

    private val doorRef = db
        .child("devices")
        .child("door01")


    // =========================================================
    // LOGIN
    // =========================================================

    fun login(
        email: String,
        password: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {

        auth.signInWithEmailAndPassword(
            email,
            password
        )
            .addOnSuccessListener {

                onSuccess()
            }
            .addOnFailureListener { exception ->

                onError(
                    exception.message
                        ?: "Login failed."
                )
            }
    }


    // =========================================================
    // REGISTER FIREBASE ACCOUNT
    // =========================================================

    fun register(
        email: String,
        password: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {

        auth.createUserWithEmailAndPassword(
            email,
            password
        )
            .addOnSuccessListener {

                onSuccess()
            }
            .addOnFailureListener { exception ->

                onError(
                    exception.message
                        ?: "Registration failed."
                )
            }
    }


    // =========================================================
    // PASSWORD RESET
    // =========================================================

    fun sendPasswordReset(
        email: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {

        auth.sendPasswordResetEmail(email)
            .addOnSuccessListener {

                onSuccess()
            }
            .addOnFailureListener { exception ->

                onError(
                    exception.message
                        ?: "Password reset failed."
                )
            }
    }


    // =========================================================
    // CHANGE PASSWORD
    // =========================================================

    fun changePassword(
        currentPassword: String,
        newPassword: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {

        val user = auth.currentUser

        if (user == null) {

            onError(
                "No user is currently logged in."
            )

            return
        }

        val email = user.email

        if (email == null) {

            onError(
                "User email is unavailable."
            )

            return
        }

        val credential =
            EmailAuthProvider.getCredential(
                email,
                currentPassword
            )

        user.reauthenticate(credential)
            .addOnSuccessListener {

                user.updatePassword(newPassword)
                    .addOnSuccessListener {

                        onSuccess()
                    }
                    .addOnFailureListener { exception ->

                        onError(
                            exception.message
                                ?: "Password update failed."
                        )
                    }
            }
            .addOnFailureListener { exception ->

                onError(
                    exception.message
                        ?: "Current password is incorrect."
                )
            }
    }


    // =========================================================
    // GET CURRENT USER EMAIL
    // =========================================================

    fun getCurrentUserEmail(): String {

        return auth.currentUser?.email
            ?: "Unknown user"
    }


    // =========================================================
    // GET CURRENT USER ID
    // =========================================================

    fun getCurrentUserId(): String {

        return auth.currentUser?.uid
            ?: ""
    }


    // =========================================================
    // CHECK LOGIN
    // =========================================================

    fun isUserLoggedIn(): Boolean {

        return auth.currentUser != null
    }


    // =========================================================
    // LOGOUT
    // =========================================================

    fun logout() {

        auth.signOut()
    }


    // =========================================================
    // CHECK IF CURRENT USER ALREADY OWNS A DOOR
    //
    // users/{uid}/doorId
    //
    // One account = one door
    // =========================================================

    fun checkUserDoor(
        onResult: (String?) -> Unit,
        onError: (String) -> Unit
    ) {

        val user = auth.currentUser

        if (user == null) {

            onError(
                "You must be logged in."
            )

            return
        }

        db.child("users")
            .child(user.uid)
            .child("doorId")
            .get()
            .addOnSuccessListener { snapshot ->

                val doorId =
                    snapshot.getValue(String::class.java)

                onResult(doorId)
            }
            .addOnFailureListener { exception ->

                onError(
                    exception.message
                        ?: "Unable to check account."
                )
            }
    }


    // =========================================================
    // REGISTER DOOR
    //
    // One door = one account
    //
    // Door structure:
    //
    // devices
    //   door01
    //      ownerUid
    //      ownerEmail
    //      command
    //      status
    //
    // User structure:
    //
    // users
    //   UID
    //      email
    //      doorId
    //
    // =========================================================

    fun registerDoor(
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {

        val user = auth.currentUser

        if (user == null) {

            onError(
                "You must be logged in."
            )

            return
        }

        val uid = user.uid

        val email =
            user.email ?: "Unknown user"


        // -----------------------------------------------------
        // First check whether this account already owns a door
        // -----------------------------------------------------

        db.child("users")
            .child(uid)
            .child("doorId")
            .get()
            .addOnSuccessListener { userDoorSnapshot ->

                val existingDoor =
                    userDoorSnapshot
                        .getValue(String::class.java)

                if (!existingDoor.isNullOrBlank()) {

                    onError(
                        "Your account is already registered to $existingDoor."
                    )

                    return@addOnSuccessListener
                }


                // -------------------------------------------------
                // Atomically claim Door 1
                // -------------------------------------------------

                doorRef.runTransaction(
                    object :
                        com.google.firebase.database.Transaction.Handler {

                        override fun doTransaction(
                            currentData: com.google.firebase.database.MutableData
                        ): com.google.firebase.database.Transaction.Result {

                            val ownerUid =
                                currentData
                                    .child("ownerUid")
                                    .getValue(String::class.java)

                            // Door already has an owner
                            if (!ownerUid.isNullOrBlank()) {

                                if (ownerUid == uid) {

                                    return com.google.firebase.database.Transaction.abort()
                                }

                                return com.google.firebase.database.Transaction.abort()
                            }


                            // Door is available
                            currentData
                                .child("ownerUid")
                                .value = uid

                            currentData
                                .child("ownerEmail")
                                .value = email

                            return com.google.firebase.database.Transaction.success(
                                currentData
                            )
                        }


                        override fun onComplete(
                            error: DatabaseError?,
                            committed: Boolean,
                            currentData: DataSnapshot?
                        ) {

                            if (error != null) {

                                onError(
                                    error.message
                                )

                                return
                            }


                            if (!committed) {

                                val ownerUid =
                                    currentData
                                        ?.child("ownerUid")
                                        ?.getValue(String::class.java)

                                if (ownerUid == uid) {

                                    onError(
                                        "This door is already registered to your account."
                                    )

                                } else {

                                    onError(
                                        "Door 1 is already registered to another account."
                                    )
                                }

                                return
                            }


                            // -----------------------------------------
                            // Door successfully claimed
                            // -----------------------------------------

                            val userUpdates =
                                hashMapOf<String, Any>(

                                    "email" to email,

                                    "doorId" to "door01"
                                )

                            db.child("users")
                                .child(uid)
                                .updateChildren(userUpdates)
                                .addOnSuccessListener {

                                    onSuccess()
                                }
                                .addOnFailureListener { exception ->

                                    onError(
                                        exception.message
                                            ?: "Door registered, but account information could not be saved."
                                    )
                                }
                        }
                    }
                )
            }
            .addOnFailureListener { exception ->

                onError(
                    exception.message
                        ?: "Unable to check account."
                )
            }
    }


    // =========================================================
    // GET CURRENT USER'S DOOR
    // =========================================================

    fun getCurrentUserDoor(
        onResult: (String?) -> Unit,
        onError: (String) -> Unit
    ) {

        val user = auth.currentUser

        if (user == null) {

            onError(
                "You must be logged in."
            )

            return
        }

        db.child("users")
            .child(user.uid)
            .child("doorId")
            .get()
            .addOnSuccessListener { snapshot ->

                val doorId =
                    snapshot.getValue(String::class.java)

                onResult(doorId)
            }
            .addOnFailureListener { exception ->

                onError(
                    exception.message
                        ?: "Unable to retrieve your door."
                )
            }
    }


    // =========================================================
    // VERIFY DOOR OWNERSHIP
    //
    // Returns true only when the current Firebase user
    // owns Door 1.
    // =========================================================

    fun checkDoorOwnership(
        onResult: (Boolean) -> Unit,
        onError: (String) -> Unit
    ) {

        val user = auth.currentUser

        if (user == null) {

            onError(
                "You must be logged in."
            )

            return
        }

        doorRef
            .child("ownerUid")
            .get()
            .addOnSuccessListener { snapshot ->

                val ownerUid =
                    snapshot.getValue(String::class.java)

                if (ownerUid.isNullOrBlank()) {

                    onResult(false)

                    return@addOnSuccessListener
                }

                onResult(
                    ownerUid == user.uid
                )
            }
            .addOnFailureListener { exception ->

                onError(
                    exception.message
                        ?: "Unable to verify door ownership."
                )
            }
    }


    // =========================================================
    // OPEN DOOR
    //
    // Only the registered owner can open Door 1.
    // =========================================================

    fun openDoor(
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {

        val user = auth.currentUser

        if (user == null) {

            onError(
                "You must be logged in."
            )

            return
        }


        // -----------------------------------------------------
        // Verify owner before sending command
        // -----------------------------------------------------

        doorRef
            .child("ownerUid")
            .get()
            .addOnSuccessListener { snapshot ->

                val ownerUid =
                    snapshot.getValue(String::class.java)


                if (ownerUid.isNullOrBlank()) {

                    onError(
                        "This door has not been registered yet."
                    )

                    return@addOnSuccessListener
                }


                if (ownerUid != user.uid) {

                    onError(
                        "Access denied. This door is registered to another account."
                    )

                    return@addOnSuccessListener
                }


                // -------------------------------------------------
                // OWNER VERIFIED
                // -------------------------------------------------

                val email =
                    user.email ?: "Unknown user"


                val historyKey =
                    db.child("doorHistory")
                        .push()
                        .key


                if (historyKey == null) {

                    onError(
                        "Unable to create door history."
                    )

                    return@addOnSuccessListener
                }


                val updates =
                    hashMapOf<String, Any>(

                        "/devices/door01/command" to "OPEN",

                        "/doorHistory/$historyKey/action" to "OPEN",

                        "/doorHistory/$historyKey/email" to email,

                        "/doorHistory/$historyKey/uid" to user.uid,

                        "/doorHistory/$historyKey/doorId" to "door01",

                        "/doorHistory/$historyKey/timestamp"
                                to ServerValue.TIMESTAMP
                    )


                db.updateChildren(updates)
                    .addOnSuccessListener {

                        onSuccess()
                    }
                    .addOnFailureListener { exception ->

                        onError(
                            exception.message
                                ?: "Failed to send door command."
                        )
                    }
            }
            .addOnFailureListener { exception ->

                onError(
                    exception.message
                        ?: "Unable to verify door ownership."
                )
            }
    }


    // =========================================================
    // CLOSE / LOCK DOOR
    //
    // Only the registered owner can close Door 1.
    // =========================================================

    fun closeDoor(
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {

        val user = auth.currentUser

        if (user == null) {

            onError(
                "You must be logged in."
            )

            return
        }


        // -----------------------------------------------------
        // Verify owner before sending command
        // -----------------------------------------------------

        doorRef
            .child("ownerUid")
            .get()
            .addOnSuccessListener { snapshot ->

                val ownerUid =
                    snapshot.getValue(String::class.java)


                if (ownerUid.isNullOrBlank()) {

                    onError(
                        "This door has not been registered yet."
                    )

                    return@addOnSuccessListener
                }


                if (ownerUid != user.uid) {

                    onError(
                        "Access denied. This door is registered to another account."
                    )

                    return@addOnSuccessListener
                }


                // -------------------------------------------------
                // OWNER VERIFIED
                // -------------------------------------------------

                val email =
                    user.email ?: "Unknown user"


                val historyKey =
                    db.child("doorHistory")
                        .push()
                        .key


                if (historyKey == null) {

                    onError(
                        "Unable to create door history."
                    )

                    return@addOnSuccessListener
                }


                val updates =
                    hashMapOf<String, Any>(

                        "/devices/door01/command" to "CLOSE",

                        "/doorHistory/$historyKey/action" to "CLOSE",

                        "/doorHistory/$historyKey/email" to email,

                        "/doorHistory/$historyKey/uid" to user.uid,

                        "/doorHistory/$historyKey/doorId" to "door01",

                        "/doorHistory/$historyKey/timestamp"
                                to ServerValue.TIMESTAMP
                    )


                db.updateChildren(updates)
                    .addOnSuccessListener {

                        onSuccess()
                    }
                    .addOnFailureListener { exception ->

                        onError(
                            exception.message
                                ?: "Failed to send lock command."
                        )
                    }
            }
            .addOnFailureListener { exception ->

                onError(
                    exception.message
                        ?: "Unable to verify door ownership."
                )
            }
    }


    // =========================================================
    // LISTEN TO ACTUAL DOOR STATUS
    //
    // Only the owner's HomeActivity should use this.
    // =========================================================

    fun listenDoorStatus(
        onStatusChanged: (String) -> Unit,
        onError: (String) -> Unit
    ): ValueEventListener {

        val statusRef =
            doorRef.child("status")


        val listener =
            object : ValueEventListener {

                override fun onDataChange(
                    snapshot: DataSnapshot
                ) {

                    val status =
                        snapshot.getValue(
                            String::class.java
                        ) ?: "UNKNOWN"

                    onStatusChanged(status)
                }


                override fun onCancelled(
                    error: DatabaseError
                ) {

                    onError(
                        error.message
                    )
                }
            }


        statusRef.addValueEventListener(
            listener
        )

        return listener
    }


    // =========================================================
    // REMOVE STATUS LISTENER
    // =========================================================

    fun removeDoorStatusListener(
        listener: ValueEventListener
    ) {

        doorRef
            .child("status")
            .removeEventListener(
                listener
            )
    }
}