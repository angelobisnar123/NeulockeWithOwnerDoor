package com.example.neulocke.presenter

import com.example.neulocke.firebase.FirebaseManager
import com.google.firebase.database.ValueEventListener

class HomePresenter(
    private var view: HomeContract.View?
) : HomeContract.Presenter {


    // =========================================================
    // FIREBASE
    // =========================================================

    private val firebaseManager =
        FirebaseManager()


    // =========================================================
    // DOOR LISTENER
    // =========================================================

    private var doorStatusListener:
            ValueEventListener? = null


    // =========================================================
    // LOAD DASHBOARD
    // =========================================================

    override fun loadDashboard() {

        val email =
            firebaseManager.getCurrentUserEmail()


        view?.showUserEmail(
            email
        )


        if (!firebaseManager.isUserLoggedIn()) {

            view?.showUserStatus(
                "Account Status: Not Logged In"
            )

            return
        }


        // -----------------------------------------------------
        // Verify that this account owns Door 1
        // -----------------------------------------------------

        firebaseManager.checkDoorOwnership(

            onResult = { ownsDoor ->

                if (ownsDoor) {

                    view?.showUserStatus(
                        "Account Status: Active\nDoor: Door 1"
                    )

                } else {

                    view?.showUserStatus(
                        "Account Status: No Door Registered"
                    )


                    view?.showMessage(
                        "This account is not registered to Door 1."
                    )
                }
            },

            onError = { error ->

                view?.showUserStatus(
                    "Account Status: Verification Failed"
                )

                view?.showMessage(
                    error
                )
            }
        )
    }


    // =========================================================
    // OPEN DOOR
    // =========================================================

    override fun openDoor() {

        if (!firebaseManager.isUserLoggedIn()) {

            view?.showMessage(
                "Please log in first."
            )

            return
        }


        view?.showOpenDoorLoading()


        firebaseManager.openDoor(

            onSuccess = {

                view?.hideOpenDoorLoading()

                view?.showMessage(
                    "OPEN command sent successfully."
                )
            },

            onError = { error ->

                view?.hideOpenDoorLoading()

                view?.showMessage(
                    error
                )
            }
        )
    }


    // =========================================================
    // CLOSE / LOCK DOOR
    // =========================================================

    override fun closeDoor() {

        if (!firebaseManager.isUserLoggedIn()) {

            view?.showMessage(
                "Please log in first."
            )

            return
        }


        view?.showCloseDoorLoading()


        firebaseManager.closeDoor(

            onSuccess = {

                view?.hideCloseDoorLoading()

                view?.showMessage(
                    "CLOSE command sent successfully."
                )
            },

            onError = { error ->

                view?.hideCloseDoorLoading()

                view?.showMessage(
                    error
                )
            }
        )
    }


    // =========================================================
    // LISTEN TO REAL DOOR STATUS
    // =========================================================

    override fun listenDoorStatus() {

        if (doorStatusListener != null) {

            return
        }


        if (!firebaseManager.isUserLoggedIn()) {

            return
        }


        // -----------------------------------------------------
        // Verify owner before listening
        // -----------------------------------------------------

        firebaseManager.checkDoorOwnership(

            onResult = { ownsDoor ->

                if (!ownsDoor) {

                    view?.showDoorStatus(
                        "ACCESS DENIED"
                    )

                    return@checkDoorOwnership
                }


                // -------------------------------------------------
                // Owner verified
                // -------------------------------------------------

                doorStatusListener =
                    firebaseManager.listenDoorStatus(

                        onStatusChanged = { status ->

                            view?.showDoorStatus(
                                status
                            )
                        },

                        onError = { error ->

                            view?.showMessage(
                                "Door status error: $error"
                            )
                        }
                    )
            },

            onError = { error ->

                view?.showMessage(
                    error
                )
            }
        )
    }


    // =========================================================
    // STOP LISTENING
    // =========================================================

    override fun stopListeningDoorStatus() {

        doorStatusListener?.let {

            firebaseManager.removeDoorStatusListener(
                it
            )
        }


        doorStatusListener =
            null
    }


    // =========================================================
    // LOGOUT
    // =========================================================

    override fun logout() {

        stopListeningDoorStatus()


        firebaseManager.logout()


        view?.logoutSuccess()
    }


    // =========================================================
    // DESTROY
    // =========================================================

    override fun destroy() {

        stopListeningDoorStatus()


        view = null
    }
}