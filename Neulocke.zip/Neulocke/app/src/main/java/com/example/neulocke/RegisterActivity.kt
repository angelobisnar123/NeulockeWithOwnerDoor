package com.example.neulocke.view

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.neulocke.R
import com.example.neulocke.presenter.RegisterContract
import com.example.neulocke.presenter.RegisterPresenter
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class RegisterActivity :
    AppCompatActivity(),
    RegisterContract.View {


    // =========================================================
    // PRESENTER
    // =========================================================

    private lateinit var presenter: RegisterPresenter


    // =========================================================
    // INPUTS
    // =========================================================

    private lateinit var etEmail: TextInputEditText

    private lateinit var etPassword: TextInputEditText

    private lateinit var etConfirmPassword: TextInputEditText


    // =========================================================
    // BUTTONS / VIEWS
    // =========================================================

    private lateinit var btnRegister: MaterialButton

    private lateinit var progressBar: ProgressBar

    private lateinit var tvLogin: TextView


    // =========================================================
    // ON CREATE
    // =========================================================

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {

        super.onCreate(
            savedInstanceState
        )


        setContentView(
            R.layout.activity_register
        )


        // -----------------------------------------------------
        // Presenter
        // -----------------------------------------------------

        presenter =
            RegisterPresenter(this)


        // -----------------------------------------------------
        // Find views
        // -----------------------------------------------------

        etEmail =
            findViewById(
                R.id.etEmail
            )


        etPassword =
            findViewById(
                R.id.etPassword
            )


        etConfirmPassword =
            findViewById(
                R.id.etConfirmPassword
            )


        btnRegister =
            findViewById(
                R.id.btnRegister
            )


        progressBar =
            findViewById(
                R.id.progressBar
            )


        tvLogin =
            findViewById(
                R.id.tvLogin
            )


        // =====================================================
        // REGISTER BUTTON
        // =====================================================

        btnRegister.setOnClickListener {

            val email =
                etEmail.text
                    .toString()
                    .trim()


            val password =
                etPassword.text
                    .toString()


            val confirmPassword =
                etConfirmPassword.text
                    .toString()


            presenter.register(
                email,
                password,
                confirmPassword
            )
        }


        // =====================================================
        // LOGIN
        // =====================================================

        tvLogin.setOnClickListener {

            finish()
        }
    }


    // =========================================================
    // SHOW LOADING
    // =========================================================

    override fun showLoading() {

        progressBar.visibility =
            View.VISIBLE


        btnRegister.isEnabled =
            false
    }


    // =========================================================
    // HIDE LOADING
    // =========================================================

    override fun hideLoading() {

        progressBar.visibility =
            View.GONE


        btnRegister.isEnabled =
            true
    }


    // =========================================================
    // ERROR
    // =========================================================

    override fun showError(
        message: String
    ) {

        Toast.makeText(
            this,
            message,
            Toast.LENGTH_LONG
        ).show()
    }


    // =========================================================
    // REGISTRATION SUCCESS
    //
    // Account exists now.
    // Send user to Door Registration.
    // =========================================================

    override fun registerSuccess() {

        Toast.makeText(
            this,
            "Account created successfully!",
            Toast.LENGTH_SHORT
        ).show()


        val intent =
            Intent(
                this,
                DoorRegistrationActivity::class.java
            )


        startActivity(intent)

        finish()
    }


    // =========================================================
    // DESTROY
    // =========================================================

    override fun onDestroy() {

        presenter.destroy()

        super.onDestroy()
    }
}