package com.example.neulocke.view

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.neulocke.R
import com.example.neulocke.firebase.FirebaseManager
import com.google.android.material.button.MaterialButton

class DoorRegistrationActivity :
    AppCompatActivity() {


    // =========================================================
    // FIREBASE
    // =========================================================

    private lateinit var firebaseManager:
            FirebaseManager


    // =========================================================
    // VIEWS
    // =========================================================

    private lateinit var tvEmail:
            TextView

    private lateinit var tvDoorStatus:
            TextView

    private lateinit var btnRegisterDoor:
            MaterialButton

    private lateinit var progressBar:
            ProgressBar


    // =========================================================
    // ON CREATE
    // =========================================================

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {

        super.onCreate(
            savedInstanceState
        )


        setContentView(
            R.layout.activity_door_registration
        )


        // -----------------------------------------------------
        // Firebase
        // -----------------------------------------------------

        firebaseManager =
            FirebaseManager()


        // -----------------------------------------------------
        // Find views
        // -----------------------------------------------------

        tvEmail =
            findViewById(
                R.id.tvEmail
            )


        tvDoorStatus =
            findViewById(
                R.id.tvDoorStatus
            )


        btnRegisterDoor =
            findViewById(
                R.id.btnRegisterDoor
            )


        progressBar =
            findViewById(
                R.id.progressBar
            )


        // -----------------------------------------------------
        // Show current email
        // -----------------------------------------------------

        tvEmail.text =
            "Account: ${firebaseManager.getCurrentUserEmail()}"


        // -----------------------------------------------------
        // Check whether account already owns a door
        // -----------------------------------------------------

        checkExistingDoor()


        // =====================================================
        // REGISTER DOOR
        // =====================================================

        btnRegisterDoor.setOnClickListener {

            registerDoor()
        }
    }


    // =========================================================
    // CHECK EXISTING DOOR
    // =========================================================

    private fun checkExistingDoor() {

        firebaseManager.checkUserDoor(

            onResult = { doorId ->

                runOnUiThread {

                    if (!doorId.isNullOrBlank()) {

                        tvDoorStatus.text =
                            "Door Status: Already Registered ($doorId)"


                        btnRegisterDoor.isEnabled =
                            false

                    } else {

                        tvDoorStatus.text =
                            "Door 1 Status: Available"


                        btnRegisterDoor.isEnabled =
                            true
                    }
                }
            },

            onError = { error ->

                runOnUiThread {

                    Toast.makeText(
                        this,
                        error,
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        )
    }


    // =========================================================
    // REGISTER DOOR
    // =========================================================

    private fun registerDoor() {

        showLoading()


        firebaseManager.registerDoor(

            onSuccess = {

                runOnUiThread {

                    hideLoading()


                    Toast.makeText(
                        this,
                        "Door 1 registered successfully!",
                        Toast.LENGTH_LONG
                    ).show()


                    // -----------------------------------------
                    // Go to Home
                    // -----------------------------------------

                    val intent =
                        Intent(
                            this,
                            HomeActivity::class.java
                        )


                    intent.flags =
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                                Intent.FLAG_ACTIVITY_CLEAR_TASK


                    startActivity(
                        intent
                    )


                    finish()
                }
            },

            onError = { error ->

                runOnUiThread {

                    hideLoading()


                    Toast.makeText(
                        this,
                        error,
                        Toast.LENGTH_LONG
                    ).show()


                    // Re-check because another account
                    // may have claimed the door.
                    checkExistingDoor()
                }
            }
        )
    }


    // =========================================================
    // LOADING
    // =========================================================

    private fun showLoading() {

        progressBar.visibility =
            View.VISIBLE


        btnRegisterDoor.isEnabled =
            false


        btnRegisterDoor.text =
            "Registering..."
    }


    // =========================================================
    // STOP LOADING
    // =========================================================

    private fun hideLoading() {

        progressBar.visibility =
            View.GONE


        btnRegisterDoor.isEnabled =
            true


        btnRegisterDoor.text =
            "REGISTER DOOR"
    }
}